/* مساحتي — Service Worker: تشغيل كامل بدون إنترنت */
const V='masahati-v4';
const CORE=['./','masahati.html','din-system.js','quran-pages.json','manifest.webmanifest','favicon.png','apple-touch-icon.png','icon-192.png','icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request;
  if(r.method!=='GET'||new URL(r.url).origin!==location.origin)return;
  e.respondWith(caches.open(V).then(async c=>{
    const hit=await c.match(r,{ignoreSearch:true});
    const net=fetch(r).then(res=>{if(res&&res.ok)c.put(r,res.clone());return res}).catch(()=>null);
    if(hit){e.waitUntil(net);return hit}            /* من الكاش فورًا + تحديث في الخلفية */
    const res=await net;
    if(res)return res;
    if(r.mode==='navigate')return (await c.match('masahati.html'))||Response.error();
    return Response.error();
  }));
});
