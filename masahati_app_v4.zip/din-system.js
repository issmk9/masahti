/* Browser-safe religious tracking rules, shared with regression tests. */
(function(root){
  const prayers=['fajr','dhuhr','asr','maghrib','isha'];
  const nonnegative=n=>Number.isFinite(+n)?Math.max(0,Math.floor(+n)):0;
  function normalize(value){
    const v=value&&typeof value==='object'?value:{};
    return {days:v.days&&typeof v.days==='object'?v.days:{},page:Math.min(604,Math.max(1,nonnegative(v.page)||1)),pagesRead:nonnegative(v.pagesRead),khatmas:nonnegative(v.khatmas)};
  }
  const dayOf=(state,day)=>state.days[day]||(state.days[day]={dhikr:{},quran:0});
  function dhikr(state,day,label,delta){
    const d=dayOf(state,day);
    d.dhikr=d.dhikr&&typeof d.dhikr==='object'?d.dhikr:{};
    d.dhikr[label]=Math.max(0,nonnegative(d.dhikr[label])+delta);
  }
  /* دعاء قضاء الدين: مرة واحدة في اليوم، من غير عداد */
  function setDebt(state,day,on){dayOf(state,day).debt=on?1:0}
  /* wl: {يوم:{ml,goal}} من متتبع المياه (اختياري) */
  function totals(state,pd,day,wl){
    const d=state.days[day]||{},w=(wl&&wl[day])||{},ml=nonnegative(w.ml),goal=Math.max(1,nonnegative(w.goal)||2000);
    return {dhikr:Object.values(d.dhikr||{}).reduce((s,n)=>s+nonnegative(n),0),prayers:prayers.filter(k=>!!(pd[day]||{})[k]).length,quran:nonnegative(d.quran),debt:nonnegative(d.debt)>0?1:0,water:ml,waterGoal:goal,waterDone:ml>=goal};
  }
  function completeReading(state,day){
    const read=state.page,d=dayOf(state,day);
    d.quran=nonnegative(d.quran)+1;state.pagesRead++;
    if(read===604){state.page=1;state.khatmas++}else state.page=read+1;
    return read;
  }
  function habitDays(state,pd,source,wl){
    const result={};
    for(const day of new Set([...Object.keys(state.days),...Object.keys(pd),...Object.keys(wl||{})])){
      const t=totals(state,pd,day,wl);
      if(source==='dhikr'?t.dhikr>=100:source==='prayers'?t.prayers===5:source==='quran'?t.quran>=1:source==='debt'?t.debt===1:source==='water'?t.waterDone&&t.water>0:false)result[day]=1;
    }
    return result;
  }
  function achievements(state,pd,wl){
    const n=s=>Object.keys(habitDays(state,pd,s,wl)).length;
    const dh=n('dhikr'),pr=n('prayers'),qr=n('quran'),db=n('debt'),wt=n('water');
    return [{name:'مائة ذكر',value:dh,target:1},{name:'الصلوات الخمس',value:pr,target:1},{name:'أول صفحة قرآن',value:qr,target:1},{name:'سبعة أيام قرآن',value:qr,target:7},{name:'ختمة قرآن',value:state.khatmas,target:1},{name:'دعاء قضاء الدين',value:db,target:1},{name:'سبعة أيام دعاء',value:db,target:7},{name:'هدف الماء',value:wt,target:1},{name:'سبعة أيام ماء',value:wt,target:7}];
  }
  root.MasahatiDin={normalize,dhikr,setDebt,totals,completeReading,habitDays,achievements};
})(globalThis);
